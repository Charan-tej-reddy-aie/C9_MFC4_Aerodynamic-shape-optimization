@echo off
setlocal enabledelayedexpansion

echo ========================================
echo SU2_N - REAL SU2 SIMULATIONS (FIXED)
echo Using SU2 from: C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
echo ========================================
echo.

:: Set SU2 path
set SU2_PATH=C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
set PATH=%SU2_PATH%;%PATH%

echo SU2 Path: %SU2_PATH%
echo.

:: Check SU2 is available
where SU2_CFD >nul 2>nul
if errorlevel 1 (
    echo ERROR: SU2_CFD not found
    pause
    exit /b 1
) else (
    echo SU2 found: %SU2_PATH%\SU2_CFD.exe
)

:: Create directories
if not exist "results" mkdir results
if not exist "results\naca0012" mkdir results\naca0012
if not exist "paraview\data" mkdir paraview\data

:: Step 1: Run NACA0012 simulation with fixed config
echo.
echo [1/4] Running NACA0012 RANS simulation...
echo Using corrected configuration file...
echo.

cd configs
"%SU2_PATH%\SU2_CFD.exe" naca0012_fixed.cfg

if errorlevel 1 (
    echo WARNING: NACA0012 simulation had issues
) else (
    echo SUCCESS: NACA0012 simulation complete
    if exist "flow.dat" copy flow.dat ..\results\naca0012\ >nul
    if exist "history.csv" copy history.csv ..\results\naca0012\ >nul
)

:: Step 2: Check for adjoint solver (may be different name)
echo.
echo [2/4] Looking for adjoint solver...
if exist "%SU2_PATH%\SU2_CFD_AD.exe" (
    set ADJOINT_EXE=SU2_CFD_AD.exe
) else if exist "%SU2_PATH%\SU2_CFD" (
    echo Adjoint may be integrated. Try: SU2_CFD --adjoint
    set ADJOINT_EXE=SU2_CFD --adjoint
) else (
    echo Adjoint solver not found separately - may be part of main SU2_CFD
)

:: Step 3: Demonstrate RBF mesh deformation
echo.
echo [3/4] Creating RBF deformation config...
(
echo MESH_DEFORM= YES
echo MESH_DEFORM_METHOD= RBF
echo RBF_FUNCTION= WENDLAND_C2
echo RBF_POINT_SELECTION= GREEDY
echo RBF_GREEDY_TOL= 1E-4
echo RBF_MAX_POINTS= 2000
echo MESH_IN_FILENAME= ../meshes/naca0012/mesh.su2
echo MESH_OUT_FILENAME= ../results/naca0012/mesh_deformed.su2
) > rbf_deform.cfg

echo Running RBF mesh deformation...
"%SU2_PATH%\SU2_DEF.exe" rbf_deform.cfg

:: Step 4: Convert results for ParaView
echo.
echo [4/4] Checking for results to visualize...

:: Look for VTK files
if exist "*.vtk" (
    copy *.vtk ..\paraview\data\ >nul
    echo VTK files copied to paraview\data\
) else (
    echo No VTK files found yet. They will appear after successful simulation.
)

cd ..

echo.
echo ========================================
echo SIMULATIONS ATTEMPTED
echo ========================================
echo.
echo Check results in: results\naca0012\
echo.
echo To visualize (if simulation succeeded):
echo   1. Open ParaView
echo   2. File -> Open -> paraview\data\*.vtk
echo   3. Click Apply
echo.
pause
