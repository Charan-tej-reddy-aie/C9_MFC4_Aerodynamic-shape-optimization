@echo off
setlocal enabledelayedexpansion

echo ========================================
echo SU2_N - REAL SU2 SIMULATIONS
echo Using SU2 from: C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
echo Based on paper: Aerodynamic shape optimization with RBF
echo ========================================
echo.

:: Set SU2 path
set SU2_PATH=C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
set PATH=%SU2_PATH%;%PATH%

echo SU2 Path: %SU2_PATH%
echo.

:: Check SU2 is available
where SU2_CFD >nul 2>nul
if errorlevel 1 (
    echo ERROR: SU2_CFD not found in PATH
    echo Please check installation at: %SU2_PATH%
    pause
    exit /b 1
) else (
    echo SU2 found successfully!
)

:: Create directories
if not exist "results" mkdir results
if not exist "results\naca0012" mkdir results\naca0012
if not exist "results\onera_m6" mkdir results\onera_m6

:: Step 1: Run NACA0012 simulation
echo.
echo [1/4] Running NACA0012 RANS simulation...
cd configs
echo This will take approximately 30-60 minutes...
echo.
"%SU2_PATH%\SU2_CFD.exe" naca0012.cfg

if errorlevel 1 (
    echo WARNING: NACA0012 simulation had issues
) else (
    echo SUCCESS: NACA0012 simulation complete
    copy flow.dat ..\results\naca0012\ >nul
    copy history.csv ..\results\naca0012\ >nul
)

:: Step 2: Run discrete adjoint for sensitivity
echo.
echo [2/4] Running discrete adjoint for NACA0012...
"%SU2_PATH%\SU2_CFD_AD.exe" -adjoint naca0012.cfg

if errorlevel 1 (
    echo WARNING: Adjoint simulation had issues
) else (
    echo SUCCESS: Adjoint simulation complete
    copy sensitivity.dat ..\results\naca0012\ >nul
)

:: Step 3: Demonstrate RBF mesh deformation (sample)
echo.
echo [3/4] Demonstrating RBF mesh deformation...
copy naca0012.cfg naca0012_deform.cfg
echo MESH_DEFORM= YES >> naca0012_deform.cfg
echo MESH_DEFORM_METHOD= RBF >> naca0012_deform.cfg
echo RBF_FUNCTION= WENDLAND_C2 >> naca0012_deform.cfg
echo RBF_POINT_SELECTION= GREEDY >> naca0012_deform.cfg
echo RBF_MAX_POINTS= 2000 >> naca0012_deform.cfg
echo RBF_MULTILEVEL= YES >> naca0012_deform.cfg

"%SU2_PATH%\SU2_DEF.exe" -f naca0012_deform.cfg

:: Step 4: Convert results for ParaView
echo.
echo [4/4] Converting results for ParaView...
if exist "flow.vtk" (
    copy flow.vtk ..\paraview\data\naca0012_flow.vtk
    echo Files copied to paraview\data\
)

cd ..

echo.
echo ========================================
echo SIMULATIONS COMPLETE
echo ========================================
echo.
echo Results saved in:
echo   - results\naca0012\flow.dat
echo   - results\naca0012\history.csv
echo   - results\naca0012\sensitivity.dat
echo.
echo ParaView files:
echo   - paraview\data\naca0012_flow.vtk
echo.
echo To visualize in ParaView:
echo   1. Open ParaView
echo   2. File -> Open -> paraview\data\naca0012_flow.vtk
echo   3. Click Apply
echo   4. Color by Pressure or Mach
echo.
pause
