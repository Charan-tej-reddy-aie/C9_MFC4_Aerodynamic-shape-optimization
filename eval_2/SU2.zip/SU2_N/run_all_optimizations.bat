@echo off
setlocal enabledelayedexpansion

echo ========================================
echo SU2 - COMPLETE SLSQP OPTIMIZATION PIPELINE
echo All 4 Test Cases from the Paper
echo ========================================
echo.

:: Set SU2 path
set SU2_PATH=C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
set PATH=%SU2_PATH%;%PATH%

echo SU2 Path: %SU2_PATH%
echo.

:: Check Python
python --version >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python not found
    pause
    exit /b 1
)

:: Install required packages
echo Installing Python packages...
pip install numpy matplotlib scipy

:: Create necessary directories
echo Creating directory structure...
mkdir optimization\results\naca0012 2>nul
mkdir optimization\results\onera_m6 2>nul
mkdir optimization\results\winglet 2>nul
mkdir optimization\results\nrel 2>nul
mkdir optimization\logs\naca0012 2>nul
mkdir optimization\logs\onera_m6 2>nul
mkdir optimization\logs\winglet 2>nul
mkdir optimization\logs\nrel 2>nul
mkdir optimization\mesh_deformed\naca0012 2>nul
mkdir optimization\mesh_deformed\onera_m6 2>nul
mkdir optimization\mesh_deformed\winglet 2>nul
mkdir optimization\mesh_deformed\nrel 2>nul

:: Run optimization
echo.
echo ========================================
echo Starting SLSQP Optimization for all cases
echo This will take several hours...
echo ========================================
echo.

cd optimization
python run_slsqp_optimization.py

cd ..

echo.
echo ========================================
echo OPTIMIZATION COMPLETE!
echo ========================================
echo.
echo Results saved in:
echo   - optimization/results/naca0012/
echo   - optimization/results/onera_m6/
echo   - optimization/results/winglet/
echo   - optimization/results/nrel/
echo.
echo Convergence plots generated for each case
echo.
echo To view in ParaView:
echo   start "" "C:\Users\devin\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\ParaView 6.0.1\ParaView 6.0.1.lnk"
echo   File -> Open -> optimization/results/[case]/flow_iter_*.vtu
echo.
pause
