@echo off
echo ========================================
echo SU2_N - PATH FIX AND TEST
echo ========================================
echo.

:: Add SU2 to current session PATH
set SU2_PATH=C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
set PATH=%SU2_PATH%;%PATH%

echo SU2 Path added: %SU2_PATH%
echo.

:: Verify SU2 is accessible
where SU2_CFD
if errorlevel 1 (
    echo ? SU2_CFD still not found
) else (
    echo ? SU2_CFD found successfully!
)

:: Add to system PATH permanently (requires admin)
echo.
echo To add SU2 to system PATH permanently:
echo   1. Open System Properties (Win + Pause/Break)
echo   2. Click "Advanced system settings"
echo   3. Click "Environment Variables"
echo   4. Under "System variables", find "Path"
echo   5. Click "Edit" and add: C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
echo   6. Click OK on all windows
echo.

:: Test with fixed config
echo.
echo Testing SU2 with fixed config...
cd configs
"%SU2_PATH%\SU2_CFD.exe" naca0012_fixed.cfg

if errorlevel 1 (
    echo ? Test failed
) else (
    echo ? Test successful!
)

cd ..
echo.
pause
