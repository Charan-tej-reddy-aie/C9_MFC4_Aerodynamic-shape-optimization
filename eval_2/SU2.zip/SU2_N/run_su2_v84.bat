@echo off
setlocal enabledelayedexpansion

echo ========================================
echo SU2_N - REAL SU2 v8.4.0 SIMULATIONS
echo Using SU2 from: C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
echo ========================================
echo.

:: Set SU2 path
set SU2_PATH=C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
set PATH=%SU2_PATH%;%PATH%

echo SU2 Path: %SU2_PATH%
echo.

:: Check SU2 is available
"%SU2_PATH%\SU2_CFD.exe" --version
if errorlevel 1 (
    echo ERROR: SU2_CFD not found
    pause
    exit /b 1
)

:: Create directories
if not exist "results" mkdir results
if not exist "results\naca0012" mkdir results\naca0012
if not exist "paraview\data" mkdir paraview\data

:: Step 1: Run NACA0012 simulation
echo.
echo [1/4] Running NACA0012 RANS simulation (500 iterations)...
echo.

cd configs
"%SU2_PATH%\SU2_CFD.exe" naca0012_v84.cfg

if errorlevel 1 (
    echo WARNING: NACA0012 simulation had issues
) else (
    echo SUCCESS: NACA0012 simulation complete
    if exist "flow.dat" copy flow.dat ..\results\naca0012\ >nul
    if exist "history.csv" copy history.csv ..\results\naca0012\ >nul
)

:: Step 2: Convert to VTK for visualization
echo.
echo [2/4] Converting results to VTK...
if exist "flow.dat" (
    "%SU2_PATH%\SU2_SOL.exe" naca0012_v84.cfg
    if exist "flow.vtk" copy flow.vtk ..\paraview\data\naca0012_flow.vtk
)

:: Step 3: Run RBF mesh deformation
echo.
echo [3/4] Running RBF mesh deformation...
"%SU2_PATH%\SU2_DEF.exe" rbf_v84.cfg

if errorlevel 1 (
    echo RBF deformation had issues - checking config...
) else (
    echo RBF deformation complete
)

:: Step 4: Test adjoint (if available)
echo.
echo [4/4] Testing adjoint capability...
if exist "%SU2_PATH%\SU2_CFD_AD.exe" (
    echo Adjoint solver found. Would run: SU2_CFD_AD -adjoint naca0012_v84.cfg
    echo For now, skipping adjoint to save time.
) else (
    echo Note: Discrete adjoint may require separate compilation
    echo See: https://su2code.github.io/docs_v7/Adjoint/
)

cd ..

echo.
echo ========================================
echo SIMULATIONS COMPLETE
echo ========================================
echo.
echo Results location: results\naca0012\
echo ParaView files: paraview\data\
echo.
echo To visualize in ParaView:
echo   1. Open ParaView
echo   2. File -> Open -> paraview\data\naca0012_flow.vtk
echo   3. Click Apply
echo   4. Color by Pressure or Mach
echo.
pause
