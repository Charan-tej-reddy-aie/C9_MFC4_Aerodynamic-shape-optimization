@echo off
echo ========================================
echo SU2_N - VERIFY ALL FIXES
echo ========================================
echo.

:: Set SU2 path
set SU2_PATH=C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
set PATH=%SU2_PATH%;%PATH%

echo STEP 1: Checking SU2 installation...
where SU2_CFD >nul 2>nul
if errorlevel 1 (
    echo ? SU2_CFD not found
    echo Run: fix_su2_path.bat first
    pause
    exit /b 1
) else (
    echo ? SU2_CFD found
)

echo.
echo STEP 2: Testing fixed mesh (element type 5)...
cd configs
"%SU2_PATH%\SU2_CFD.exe" naca0012_fixed.cfg --stop 1 >nul 2>nul
if errorlevel 1 (
    echo ? Mesh test failed
) else (
    echo ? Mesh test passed - Element type 5 working
)

echo.
echo STEP 3: Testing CFL_ADAPT=NO setting...
findstr "CFL_ADAPT= NO" naca0012_fixed.cfg >nul
if errorlevel 1 (
    echo ? CFL_ADAPT not set to NO
) else (
    echo ? CFL_ADAPT=NO confirmed
)

echo.
echo STEP 4: Testing RBF config syntax...
"%SU2_PATH%\SU2_DEF.exe" rbf_fixed.cfg --stop 1 >nul 2>nul
if errorlevel 1 (
    echo ? RBF config has syntax errors
) else (
    echo ? RBF config syntax correct
)

echo.
echo ========================================
echo FIXES VERIFICATION COMPLETE
echo ========================================
echo.
echo If all tests passed, your SU2_N project is fully fixed!
echo.
echo Next steps:
echo   1. Run optimization: cd optimization && python run_slsqp_clean.py
echo   2. View results: start optimization\results\naca0012\convergence.png
echo.
pause
