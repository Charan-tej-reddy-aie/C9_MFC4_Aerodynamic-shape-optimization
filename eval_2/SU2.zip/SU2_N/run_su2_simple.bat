@echo off
setlocal enabledelayedexpansion

echo ========================================
echo SU2_N - SU2 v8.4.0 SIMULATION
echo ========================================
echo.

:: Set SU2 path
set SU2_PATH=C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
set PATH=%SU2_PATH%;%PATH%

echo SU2 Path: %SU2_PATH%
echo.

:: Check SU2
if exist "%SU2_PATH%\SU2_CFD.exe" (
    echo ? SU2_CFD.exe found
) else (
    echo ? SU2_CFD.exe not found
    pause
    exit /b 1
)

:: Create directories
mkdir results\naca0012 2>nul
mkdir paraview\data 2>nul

:: Step 1: Run simulation
echo.
echo [1/3] Running Euler simulation...
cd configs

echo Using configuration: test_naca0012.cfg
echo.

"%SU2_PATH%\SU2_CFD.exe" test_naca0012.cfg

if errorlevel 1 (
    echo.
    echo ? Simulation failed
) else (
    echo ? Simulation successful!
    
    :: Copy results
    if exist "history.csv" copy history.csv ..\results\naca0012\ >nul
    if exist "flow.dat" copy flow.dat ..\results\naca0012\ >nul
)

:: Step 2: Convert to VTK
echo.
echo [2/3] Converting to VTK...
if exist "flow.dat" (
    "%SU2_PATH%\SU2_SOL.exe" test_naca0012.cfg
    if exist "flow.vtk" (
        copy flow.vtk ..\paraview\data\naca0012_flow.vtk
        echo ? VTK file created
    ) else (
        echo ? VTK conversion failed
    )
) else (
    echo No flow.dat found, skipping VTK conversion
)

cd ..

:: Step 3: Show results
echo.
echo [3/3] Results:
echo ========================================

if exist "results\naca0012\history.csv" (
    echo ? Results found!
    echo.
    echo First 5 lines of convergence history:
    echo ----------------------------------------
    type results\naca0012\history.csv | findstr /n . | findstr /b [1-5]
) else (
    echo ? No results yet
)

echo.
echo ========================================
echo Next steps:
echo ========================================
echo.
echo 1. If simulation succeeded, open ParaView:
echo    start "" "C:\Users\devin\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\ParaView 6.0.1\ParaView 6.0.1.lnk"
echo.
echo 2. In ParaView: File -> Open -> paraview\data\naca0012_flow.vtk
echo.
echo 3. Click Apply, then color by Pressure
echo.
pause
