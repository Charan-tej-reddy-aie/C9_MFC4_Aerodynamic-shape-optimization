import matplotlib.pyplot as plt
import numpy as np

# Data from Table 7
methods = ['RBF (10%)', 'RBF (C2)', 'ELA']
ram = [2.55, 2.74, 14.8]
time = [3.33, 6.53, 13.66]
error = [1.07, 0.15, 0.0]

fig, axes = plt.subplots(1, 3, figsize=(15, 6))
x = np.arange(len(methods))
width = 0.6

# RAM plot
bars1 = axes[0].bar(x, ram, width, color=['blue', 'lightblue', 'red'])
axes[0].set_ylabel('RAM (GB)', fontsize=12)
axes[0].set_title('Memory Usage', fontsize=12, fontweight='bold')
axes[0].set_xticks(x)
axes[0].set_xticklabels(methods)
for bar in bars1:
    height = bar.get_height()
    axes[0].text(bar.get_x() + bar.get_width()/2., height,
                f'{height}GB', ha='center', va='bottom')

# Time plot
bars2 = axes[1].bar(x, time, width, color=['blue', 'lightblue', 'red'])
axes[1].set_ylabel('Time (min)', fontsize=12)
axes[1].set_title('Computational Time', fontsize=12, fontweight='bold')
axes[1].set_xticks(x)
axes[1].set_xticklabels(methods)
for bar in bars2:
    height = bar.get_height()
    axes[1].text(bar.get_x() + bar.get_width()/2., height,
                f'{height}min', ha='center', va='bottom')

# Error plot
bars3 = axes[2].bar(x, error, width, color=['blue', 'lightblue', 'red'])
axes[2].set_ylabel('Error (%)', fontsize=12)
axes[2].set_title('Interpolation Error', fontsize=12, fontweight='bold')
axes[2].set_xticks(x)
axes[2].set_xticklabels(methods)
for bar in bars3:
    height = bar.get_height()
    axes[2].text(bar.get_x() + bar.get_width()/2., height,
                f'{height}%', ha='center', va='bottom')

plt.suptitle('Table 7: Mesh Deformation Performance Comparison', fontsize=14, fontweight='bold')
plt.tight_layout()
plt.savefig('figures/table7_performance.png', dpi=300, bbox_inches='tight')
plt.close()
print("? Table 7 created")

# Create text table
with open('data/table7.txt', 'w') as f:
    f.write('='*60 + '\n')
    f.write('TABLE 7: PERFORMANCE COMPARISON\n')
    f.write('='*60 + '\n')
    f.write(f"{'Method':<15} {'RAM (GB)':<12} {'Time (min)':<12} {'Error (%)':<12}\n")
    f.write('-'*60 + '\n')
    for i in range(len(methods)):
        f.write(f"{methods[i]:<15} {ram[i]:<12.2f} {time[i]:<12.2f} {error[i]:<12.2f}\n")
    f.write('='*60 + '\n')
    f.write('RBF advantages:\n')
    f.write('- Uses 1/6 of RAM compared to ELA\n')
    f.write('- Takes 1/4 of computational time\n')
    f.write('- Better mesh quality preservation\n')
print("? Table 7 text saved")
