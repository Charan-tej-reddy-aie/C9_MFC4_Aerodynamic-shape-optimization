@echo off
setlocal enabledelayedexpansion

echo ========================================
echo SU2_N - EULER SIMULATION (Corrected)
echo ========================================
echo.

:: Set SU2 path
set SU2_PATH=C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
set PATH=%SU2_PATH%;%PATH%

echo SU2 Path: %SU2_PATH%
echo.

:: Check SU2
if exist "%SU2_PATH%\SU2_CFD.exe" (
    echo [OK] SU2_CFD.exe found
) else (
    echo [ERROR] SU2_CFD.exe not found
    pause
    exit /b 1
)

:: Clean previous results
echo Cleaning old results...
if exist "results\naca0012" rmdir /s /q results\naca0012 2>nul
if exist "configs\*.dat" del /q configs\*.dat 2>nul
if exist "configs\*.vtk" del /q configs\*.vtk 2>nul
if exist "configs\*.csv" del /q configs\*.csv 2>nul

:: Create directories
mkdir results\naca0012 2>nul
mkdir paraview\data 2>nul

:: Step 1: Run Euler simulation
echo.
echo [1/3] Running Euler simulation...
cd configs

echo Using: euler_naca0012.cfg
echo.

"%SU2_PATH%\SU2_CFD.exe" euler_naca0012.cfg

if errorlevel 1 (
    echo.
    echo [ERROR] Simulation failed
    echo.
    echo Possible issues:
    echo   - Mesh file not found or invalid
    echo   - Configuration parameters incorrect
    echo   - SU2 installation problem
) else (
    echo [OK] Simulation successful!
    
    :: Copy results
    if exist "history.csv" (
        copy history.csv ..\results\naca0012\ >nul
        echo   - history.csv saved
    )
    if exist "flow.dat" (
        copy flow.dat ..\results\naca0012\ >nul
        echo   - flow.dat saved
    )
)

:: Step 2: Convert to VTK
echo.
echo [2/3] Converting to VTK...
if exist "flow.dat" (
    "%SU2_PATH%\SU2_SOL.exe" euler_naca0012.cfg
    if exist "flow.vtk" (
        copy flow.vtk ..\paraview\data\naca0012_flow.vtk
        echo [OK] VTK file created: ..\paraview\data\naca0012_flow.vtk
    ) else (
        echo [WARNING] VTK conversion failed
    )
) else (
    echo [INFO] No flow.dat found, skipping VTK conversion
)

cd ..

:: Step 3: Show results
echo.
echo [3/3] Results:
echo ========================================

if exist "results\naca0012\history.csv" (
    echo [OK] Results found!
    echo.
    echo First 10 lines of history:
    echo ---------------------------
    type results\naca0012\history.csv | findstr /n . | findstr /b [1-10]
) else (
    echo [INFO] No results yet - simulation may have failed
)

echo.
echo ========================================
echo VISUALIZATION
echo ========================================
echo.

if exist "paraview\data\naca0012_flow.vtk" (
    echo VTK file is ready!
    echo.
    echo To open in ParaView:
    echo   1. Copy this command:
    echo      start "" "C:\Users\devin\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\ParaView 6.0.1\ParaView 6.0.1.lnk"
    echo.
    echo   2. In ParaView: File -> Open -> paraview\data\naca0012_flow.vtk
    echo   3. Click Apply
    echo   4. Color by Pressure
) else (
    echo No VTK file available.
)

echo.
pause
