import numpy as np
import matplotlib.pyplot as plt
import os

def plot_su2_results():
    """Plot results from real SU2 simulations"""
    
    # Check if results exist
    if os.path.exists('../results/naca0012/history.csv'):
        # Load SU2 history file
        data = np.loadtxt('../results/naca0012/history.csv', skiprows=1)
        
        if len(data.shape) == 1:
            iterations = np.arange(len(data))
            drag = data
        else:
            iterations = data[:, 0]
            drag = data[:, 3]  # Drag column
            
        plt.figure(figsize=(12, 8))
        plt.plot(iterations, drag, 'b-', linewidth=2)
        plt.xlabel('Iteration', fontsize=14)
        plt.ylabel('Drag Coefficient', fontsize=14)
        plt.title('NACA0012 - SU2 Convergence History', fontsize=16)
        plt.grid(True, alpha=0.3)
        plt.savefig('../paraview/screenshots/su2_convergence.png', dpi=300)
        print("? Convergence plot saved")
    else:
        print("No SU2 results found yet. Run SU2 simulations first.")

def create_paraview_state():
    """Create ParaView state file"""
    
    state_file = '../paraview/state/naca0012_state.pvsm'
    
    content = f'''<?xml version="1.0"?>
<ServerManagerState>
  <Proxy group="views" type="RenderView" id="1">
    <Property name="ViewSize" id="1.ViewSize">
      <Element index="0" value="1920"/>
      <Element index="1" value="1080"/>
    </Property>
  </Proxy>
  <Proxy group="sources" type="VTKSeriesReader" id="2">
    <Property name="FileNames">
      <Element index="0" value="C:/Users/devin/Desktop/SU2_N/paraview/data/naca0012_flow.vtk"/>
    </Property>
  </Proxy>
  <Proxy group="representations" type="UnstructuredGridRepresentation" id="3">
    <Property name="Input" id="3.Input">
      <Proxy value="2" output_port="0"/>
    </Property>
    <Property name="ColorArrayName" id="3.ColorArrayName">
      <Element index="0" value="Pressure"/>
    </Property>
  </Proxy>
</ServerManagerState>'''
    
    with open(state_file, 'w') as f:
        f.write(content)
    print(f"? ParaView state file created: {state_file}")

if __name__ == "__main__":
    print("\n" + "="*50)
    print("SU2 Results Visualization")
    print("="*50)
    plot_su2_results()
    create_paraview_state()
