import numpy as np
import matplotlib.pyplot as plt
import os

def plot_convergence():
    """Plot convergence from SU2 history file"""
    history_file = '../results/naca0012/history.csv'
    
    if os.path.exists(history_file):
        try:
            # Try to read SU2 history file
            data = np.loadtxt(history_file, skiprows=1)
            
            plt.figure(figsize=(12, 8))
            
            # If data is 2D, plot columns
            if len(data.shape) == 2:
                iterations = data[:, 0]
                drag = data[:, 3] if data.shape[1] > 3 else data[:, 1]
                
                plt.plot(iterations, drag, 'b-', linewidth=2)
                plt.xlabel('Iteration', fontsize=14)
                plt.ylabel('Drag Coefficient', fontsize=14)
                plt.title('NACA0012 - SU2 Convergence History', fontsize=16)
                plt.grid(True, alpha=0.3)
                plt.savefig('../paraview/screenshots/su2_convergence.png', dpi=300)
                print("? Convergence plot saved")
            else:
                print("History file format unexpected")
                
        except Exception as e:
            print(f"Error reading history file: {e}")
    else:
        print("No convergence history found. Run SU2 simulation first.")

def check_results():
    """Check what results we have"""
    print("\nChecking for SU2 results:")
    print("-" * 40)
    
    # Check for flow solution
    if os.path.exists('../results/naca0012/flow.dat'):
        size = os.path.getsize('../results/naca0012/flow.dat') / 1024
        print(f"? flow.dat: {size:.1f} KB")
    else:
        print("? flow.dat not found")
    
    # Check for history
    if os.path.exists('../results/naca0012/history.csv'):
        print("? history.csv found")
    else:
        print("? history.csv not found")
    
    # Check for VTK
    if os.path.exists('../paraview/data/naca0012_flow.vtk'):
        print("? VTK file found for ParaView")
    else:
        print("? VTK file not found")

if __name__ == "__main__":
    print("\n" + "="*50)
    print("SU2 Results Checker")
    print("="*50)
    check_results()
    plot_convergence()
