Write-Host "
" + "="*60 -ForegroundColor Cyan
Write-Host "SU2_N FOLDER CONTENTS DIAGNOSTIC" -ForegroundColor Cyan
Write-Host "="*60 -ForegroundColor Cyan

# Check configs folder
Write-Host "
?? CONFIGS FOLDER:" -ForegroundColor Yellow
if (Test-Path "configs") {
     = Get-ChildItem -Path "configs" -File
    if (.Count -gt 0) {
        foreach ( in ) {
            Write-Host "  ? " -ForegroundColor Green
        }
    } else {
        Write-Host "  ? Empty folder" -ForegroundColor Red
    }
}

# Check meshes folder
Write-Host "
?? MESHES FOLDER:" -ForegroundColor Yellow
if (Test-Path "meshes\naca0012") {
     = Get-ChildItem -Path "meshes\naca0012" -File
    if (.Count -gt 0) {
        foreach ( in ) {
            Write-Host "  ? naca0012/" -ForegroundColor Green
        }
    } else {
        Write-Host "  ? meshes/naca0012 is empty" -ForegroundColor Red
    }
}

# Check optimization results
Write-Host "
?? OPTIMIZATION RESULTS:" -ForegroundColor Yellow
 = @('naca0012', 'onera_m6', 'winglet', 'nrel')
foreach ( in ) {
     = "optimization\results\"
    if (Test-Path ) {
         = Get-ChildItem -Path  -File
        if (.Count -gt 0) {
            Write-Host "  ?  (0 files)" -ForegroundColor Green
            foreach ( in ) {
                Write-Host "      - " -ForegroundColor Gray
            }
        } else {
            Write-Host "  ?  is empty" -ForegroundColor Red
        }
    } else {
        Write-Host "  ?  folder missing" -ForegroundColor Red
    }
}

# Check paraview folder
Write-Host "
?? PARAVIEW FOLDER:" -ForegroundColor Yellow
if (Test-Path "paraview\data") {
     = Get-ChildItem -Path "paraview\data" -File
    if (.Count -gt 0) {
        Write-Host "  ? data/ (0 files)" -ForegroundColor Green
    } else {
        Write-Host "  ? paraview/data is empty" -ForegroundColor Red
    }
}

if (Test-Path "paraview\screenshots") {
     = Get-ChildItem -Path "paraview\screenshots" -File
    if (.Count -gt 0) {
        Write-Host "  ? screenshots/ (0 files)" -ForegroundColor Green
    } else {
        Write-Host "  ? paraview/screenshots is empty" -ForegroundColor Red
    }
}

Write-Host "
" + "="*60 -ForegroundColor Cyan
Write-Host "DIAGNOSTIC COMPLETE" -ForegroundColor Cyan
Write-Host "="*60 -ForegroundColor Cyan
