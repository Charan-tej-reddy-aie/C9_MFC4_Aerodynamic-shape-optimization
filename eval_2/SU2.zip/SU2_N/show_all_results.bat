@echo off
echo ========================================
echo SU2_N - COMPLETE PAPER RESULTS
echo All Figures and VTU Files for 4 Test Cases
echo ========================================
echo.

:: Create all results if not exists
if not exist "paper_results\figures\naca0012\fig9_drag_convergence.png" (
    echo Generating all paper results...
    cd paper_results
    python generate_naca0012_results.py
    python generate_onera_results.py
    python generate_winglet_results.py
    python generate_nrel_results.py
    python generate_table7.py
    python generate_all_figures.py
    cd ..
)

:: Open all figures
echo.
echo Opening all paper figures...
start paper_results\figures\naca0012\fig9_drag_convergence.png
start paper_results\figures\naca0012\fig10_sensitivity.png
start paper_results\figures\naca0012\fig11_cp_distribution.png
start paper_results\figures\naca0012\fig12_13_mach_contours.png
start paper_results\figures\onera_m6\fig19_onera_convergence.png
start paper_results\figures\onera_m6\fig22_onera_cp.png
start paper_results\figures\winglet\fig30_winglet_convergence.png
start paper_results\figures\nrel\fig34_nrel_results.png
start paper_results\figures\table7_performance.png
start paper_results\figures\all_paper_figures.png

:: Launch ParaView with all VTU files
echo.
echo Launching ParaView with all VTU files...
start "" "C:\Users\devin\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\ParaView 6.0.1\ParaView 6.0.1.lnk"

echo.
echo ========================================
echo FILES AVAILABLE:
echo ========================================
echo.
echo ?? NACA0012 Results:
echo    - Figures: paper_results\figures\naca0012\
echo    - VTU: paper_results\vtu_files\naca0012\flow.vtu
echo    - Data: paper_results\data\naca0012\optimization_history.csv
echo.
echo ?? ONERA M6 Results:
echo    - Figures: paper_results\figures\onera_m6\
echo    - VTU: paper_results\vtu_files\onera_m6\flow.vtu
echo    - Data: paper_results\data\onera_m6\optimization_history.csv
echo.
echo ?? Winglet Results:
echo    - Figures: paper_results\figures\winglet\
echo    - VTU: paper_results\vtu_files\winglet\flow.vtu
echo    - Data: paper_results\data\winglet\optimization_history.csv
echo.
echo ?? NREL Results:
echo    - Figures: paper_results\figures\nrel\
echo    - VTU: paper_results\vtu_files\nrel\flow.vtu
echo    - Data: paper_results\data\nrel\optimization_history.csv
echo.
echo ?? Complete Compilation:
echo    - All figures: paper_results\figures\all_paper_figures.png
echo    - Table 7: paper_results\figures\table7_performance.png
echo.
echo ========================================
echo INSTRUCTIONS FOR PARAVIEW:
echo ========================================
echo 1. File -> Open -> Select any .vtu file from:
echo    paper_results\vtu_files\[case]\flow.vtu
echo 2. Click Apply
echo 3. Color by Pressure, Mach, or Velocity
echo 4. Use filters for contours, slices, etc.
echo 5. Save screenshots to paraview\screenshots\
echo.
pause
