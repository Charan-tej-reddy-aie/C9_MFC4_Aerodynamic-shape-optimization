@echo off
setlocal enabledelayedexpansion

echo ========================================
echo SU2_N - REAL SU2 v8.4.0 SIMULATIONS
echo Using SU2 from: C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
echo ========================================
echo.

:: Set SU2 path
set SU2_PATH=C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
set PATH=%SU2_PATH%;%PATH%

echo SU2 Path: %SU2_PATH%
echo.

:: Check if SU2_CFD exists
if not exist "%SU2_PATH%\SU2_CFD.exe" (
    echo ERROR: SU2_CFD.exe not found at %SU2_PATH%
    echo.
    echo Files in SU2 bin directory:
    dir "%SU2_PATH%\*.exe"
    pause
    exit /b 1
) else (
    echo SU2_CFD.exe found successfully!
)

:: Create directories
if not exist "results" mkdir results
if not exist "results\naca0012" mkdir results\naca0012
if not exist "paraview\data" mkdir paraview\data
if not exist "paraview\screenshots" mkdir paraview\screenshots

:: Step 1: Run NACA0012 simulation
echo.
echo [1/4] Running NACA0012 RANS simulation (100 iterations for quick test)...
echo.

cd configs

:: Create a minimal working config for testing
(
echo SOLVER= EULER
echo MATH_PROBLEM= DIRECT
echo MESH_FILENAME= ../meshes/naca0012/mesh.su2
echo MESH_FORMAT= SU2
echo ITER= 100
echo MARKER_HEATFLUX= ( airfoil, 0.0 )
echo MARKER_FAR= ( farfield )
echo MACH_NUMBER= 0.76
echo AOA= 2.0
echo FREESTREAM_PRESSURE= 101325.0
echo FREESTREAM_TEMPERATURE= 215.38
echo OUTPUT_WRT_FREQ= 25
echo SCREEN_OUTPUT= INNER_ITER, RMS_DENSITY, LIFT, DRAG
echo HISTORY_OUTPUT= ITER, RMS_DENSITY, LIFT, DRAG
echo CONV_NUM_METHOD_FLOW= JST
echo JST_SENSOR_COEFF= (0.5, 0.02)
echo TIME_DISCRE_FLOW= EULER_IMPLICIT
echo CFL_NUMBER= 1.0
echo CFL_ADAPT= NO
) > test_naca0012.cfg

echo Running SU2_CFD with minimal test config...
"%SU2_PATH%\SU2_CFD.exe" test_naca0012.cfg

if errorlevel 1 (
    echo.
    echo WARNING: Test simulation had issues
) else (
    echo SUCCESS: Test simulation complete!
    if exist "history.csv" copy history.csv ..\results\naca0012\ >nul
    if exist "flow.vtk" copy flow.vtk ..\paraview\data\naca0012_flow.vtk
)

:: Step 2: Try to convert to VTK
echo.
echo [2/4] Converting to VTK format...
if exist "flow.dat" (
    "%SU2_PATH%\SU2_SOL.exe" test_naca0012.cfg
    if exist "flow.vtk" (
        copy flow.vtk ..\paraview\data\naca0012_flow.vtk
        echo VTK file created successfully!
    )
)

:: Step 3: Test RBF deformation with correct syntax for v8.4.0
echo.
echo [3/4] Testing RBF mesh deformation...
(
echo % Deformation options for SU2 v8.4.0
echo DEFORM_MESH= YES
echo DEFORM_METHOD= RBF
echo RBF_FUNCTION= WENDLAND_C2
echo RBF_POINT_SELECTION= GREEDY
echo RBF_GREEDY_TOL= 1e-4
echo RBF_MAX_POINTS= 2000
echo RBF_MULTILEVEL= YES
echo MESH_FILENAME= ../meshes/naca0012/mesh.su2
echo MESH_OUT_FILENAME= ../results/naca0012/mesh_deformed.su2
) > rbf_test.cfg

"%SU2_PATH%\SU2_DEF.exe" rbf_test.cfg

if errorlevel 1 (
    echo RBF deformation had issues. This is expected if SU2_DEF is not available.
) else (
    echo RBF deformation complete!
)

:: Step 4: Show results
echo.
echo [4/4] Results summary...
cd ..

echo.
echo ========================================
echo SIMULATION ATTEMPT COMPLETE
echo ========================================
echo.
echo Check if results were created:
dir results\naca0012\ 2>nul
echo.
echo ParaView files:
dir paraview\data\ 2>nul
echo.
echo To visualize in ParaView:
echo   1. Open ParaView
echo   2. File -> Open -> paraview\data\*.vtk
echo   3. Click Apply
echo   4. Color by Pressure
echo.
echo If no files were created, we need to check:
echo   - SU2 installation is complete
echo   - Mesh file is valid
echo   - Configuration parameters are correct
echo.
pause
