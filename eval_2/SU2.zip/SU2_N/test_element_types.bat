@echo off
setlocal enabledelayedexpansion

echo ========================================
echo SU2_N - TESTING CORRECT ELEMENT TYPES
echo ========================================
echo.

:: Set SU2 path
set SU2_PATH=C:\Users\devin\Desktop\SU2-v8.4.0-win64\win64\bin
set PATH=%SU2_PATH%;%PATH%

echo SU2 Path: %SU2_PATH%
echo.

:: First test with minimal mesh
echo [TEST 1] Running with minimal mesh (1 triangle)...
echo.

cd configs

:: Create minimal config
(
echo SOLVER= EULER
echo MATH_PROBLEM= DIRECT
echo MESH_FILENAME= ../meshes/naca0012/mesh_minimal.su2
echo MESH_FORMAT= SU2
echo ITER= 10
echo MARKER_EULER= ( airfoil )
echo MARKER_FAR= ( farfield )
echo MACH_NUMBER= 0.76
echo AOA= 2.0
echo FREESTREAM_PRESSURE= 101325.0
echo FREESTREAM_TEMPERATURE= 215.38
echo OUTPUT_WRT_FREQ= 5
echo SCREEN_OUTPUT= INNER_ITER, RMS_DENSITY
echo VOLUME_OUTPUT= NONE
echo CONV_NUM_METHOD_FLOW= JST
echo JST_SENSOR_COEFF= (0.5, 0.02)
echo CFL_NUMBER= 1.0
) > minimal_test.cfg

echo Running minimal test...
"%SU2_PATH%\SU2_CFD.exe" minimal_test.cfg

if errorlevel 1 (
    echo.
    echo ? Minimal test FAILED
    echo.
    echo Press any key to continue with full mesh test...
    pause >nul
) else (
    echo ? Minimal test SUCCESSFUL!
    echo Element type 5 works correctly!
)

echo.
echo [TEST 2] Running with full mesh...
echo.

"%SU2_PATH%\SU2_CFD.exe" euler_correct.cfg

if errorlevel 1 (
    echo.
    echo ? Full mesh test FAILED
) else (
    echo ? Full mesh test SUCCESSFUL!
    
    :: Convert to VTK
    if exist "flow.dat" (
        "%SU2_PATH%\SU2_SOL.exe" euler_correct.cfg
        if exist "flow.vtk" (
            copy flow.vtk ..\paraview\data\naca0012_flow.vtk
            echo ? VTK file created
        )
    )
)

cd ..

echo.
echo ========================================
echo TESTING COMPLETE
echo ========================================
echo.
if exist "paraview\data\naca0012_flow.vtk" (
    echo Opening ParaView...
    start "" "C:\Users\devin\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\ParaView 6.0.1\ParaView 6.0.1.lnk"
    echo.
    echo In ParaView: File -> Open -> paraview\data\naca0012_flow.vtk
    echo Click Apply, then color by Pressure
) else (
    echo No VTK file created
)
echo.
pause
